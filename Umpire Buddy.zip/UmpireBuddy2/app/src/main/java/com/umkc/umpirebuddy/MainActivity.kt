package com.umkc.umpirebuddy

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.widget.Button
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //get the view ID's
        val bScore = findViewById<TextView>(R.id.ballScoreNum)
        val sScore = findViewById<TextView>(R.id.strikeScoreNum)

        val resetButton = findViewById<Button>(R.id.reset)
        val addBallButton = findViewById<Button>(R.id.addBall)
        val addStrikeButton = findViewById<Button>(R.id.addStrike)
        val exitButton = findViewById<Button>(R.id.exit)

        var strikes: Int = 0;
        var balls: Int = 0;

        addStrikeButton.setOnClickListener {
            strikes++
            sScore.text = "$strikes"
        }

        addBallButton.setOnClickListener {
            balls++
            bScore.text = "$balls"
        }

        resetButton.setOnClickListener {
            balls = 0;
            strikes = 0;
            bScore.text = "$balls"
            sScore.text = "$strikes"
        }

        exitButton.setOnClickListener {
            finish();
            System.exit(0);
        }








    }
}
