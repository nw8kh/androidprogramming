package com.umkc.umpirebuddy

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

//Import statements for the popup window
import android.view.Gravity
import android.view.LayoutInflater
import kotlinx.android.synthetic.main.activity_main.*
import android.content.Context
import android.os.Build
import android.transition.Slide
import android.transition.Transition
import android.transition.TransitionManager
import android.widget.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //get the view ID's for textviews
        val bScore = findViewById<TextView>(R.id.ballScoreNum)
        val sScore = findViewById<TextView>(R.id.strikeScoreNum)

        //get the view ID's for buttons
        val resetButton = findViewById<Button>(R.id.reset)
        val addBallButton = findViewById<Button>(R.id.addBall)
        val addStrikeButton = findViewById<Button>(R.id.addStrike)
        val exitButton = findViewById<Button>(R.id.exit)
        val aboutButton = findViewById<Button>(R.id.about)

        var strikes: Int = 0;
        var balls: Int = 0;

        //Add strike button listener
        addStrikeButton.setOnClickListener {
            if(strikes <= 2) {
                strikes++
                sScore.text = "$strikes"
                if (strikes == 3) {
                    Toast.makeText(this, "The batter struck out!", Toast.LENGTH_LONG).show()
                    //gray out the button when max strikes has been reached
                }
            }
        }
        //Add ball button listener
        addBallButton.setOnClickListener {
            if(balls <= 3) {
                balls++
                bScore.text = "$balls"
                if(balls == 4) {
                    Toast.makeText(this, "The batter has been walked!", Toast.LENGTH_LONG).show() //create a toast to display the message
                    //gray out the button after the max has been reached
                }
            }
        }
        //Reset button listener
        resetButton.setOnClickListener {
            balls = 0;
            strikes = 0;
            bScore.text = "$balls"
            sScore.text = "$strikes"
        }

        //Exit button listener
        exitButton.setOnClickListener {
            finish();
            System.exit(0);
        }

        //About button listener
        aboutButton.setOnClickListener {
            //initialize new layout inflater
            val inflater:LayoutInflater = getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater

            //inflate a custom view via layout inflater
            val view = inflater.inflate(R.layout.another_view, null)

            //initialize a new popup window
            val popup = PopupWindow(view, LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)

            //if the popup api version is 23 or greater
            if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                //create new slide animation
                val slideIn = Slide()
                slideIn.slideEdge = Gravity.TOP
                popup.enterTransition = slideIn

                //slide animation for slide out
                val slideOut = Slide()
                slideOut.slideEdge = Gravity.RIGHT
                popup.exitTransition = slideOut
            }

            //get widget ref ID
            val popupText = view.findViewById<TextView>(R.id.popupText)
            val exitPopup = view.findViewById<Button>(R.id.exitPopup)

            //popup exit button listener
            exitPopup.setOnClickListener() {
                popup.dismiss()
            }

            //show the popup window inside the app
            TransitionManager.beginDelayedTransition(root_layout)
            popup.showAtLocation(root_layout, Gravity.CENTER, 0, 0)
        }









    }
}
